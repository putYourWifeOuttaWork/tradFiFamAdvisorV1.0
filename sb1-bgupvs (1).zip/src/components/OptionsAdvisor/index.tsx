import React from 'react';
import App from './App';

const OptionsAdvisor: React.FC = () => {
  return <App />;
};

export default OptionsAdvisor;